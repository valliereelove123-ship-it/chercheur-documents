# Eve — build de l'APK Android, 100 % depuis ta tablette

Pas besoin d'ordinateur ni d'Android Studio. GitHub compile l'app pour toi, sur ses propres
serveurs ; tu n'as qu'à envoyer le code et télécharger le résultat, depuis le navigateur de
ta tablette.

## 1. Mettre ce projet sur ton dépôt GitHub

Sur `github.com/valliereelove123-ship-it/chercheur-documents` (ou un nouveau dépôt si tu préfères) :

1. **Add file → Upload files** (en haut de la page du dépôt, dans le navigateur de ta tablette)
2. Dézippe ce projet sur ta tablette au préalable (la plupart des gestionnaires de fichiers
   Android/tablette savent extraire un .zip), puis glisse-dépose ou sélectionne **tous les
   fichiers et dossiers** de `capacitor-project/` :
   - `www/` (avec index.html, manifest.json, sw.js, icone-512.png)
   - `.github/workflows/build-apk.yml`
   - `package.json`
   - `capacitor.config.json`
3. **Commit changes**

Dès que le commit est envoyé, GitHub démarre automatiquement la compilation (le fichier
`.github/workflows/build-apk.yml` déclenche ça tout seul).

## 2. Suivre la compilation

1. Va dans l'onglet **Actions** du dépôt (en haut de la page GitHub)
2. Tu verras "Build Android APK" en cours (point orange) — ça prend 3 à 6 minutes
3. Quand c'est fini (coche verte), clique sur le run terminé

## 3. Télécharger l'APK

Sur la page du run terminé, tout en bas, section **Artifacts** : clique sur **eve-apk**
pour télécharger un `.zip` contenant `app-debug.apk`. Décompresse-le sur ta tablette.

## 4. Installer sur ta tablette (ou ton téléphone)

- Ouvre le fichier `app-debug.apk` directement depuis le gestionnaire de fichiers
- Si Android demande d'autoriser "Sources inconnues" ou "Installer des apps inconnues",
  accepte-le pour cette installation
- L'app s'installe sous le nom **Eve**, avec l'icône chien bleu

## Si tu modifies le contenu plus tard

Édite `www/index.html` directement dans l'éditeur web de GitHub (clique sur le fichier →
icône crayon → modifie → **Commit changes**). Chaque commit relance automatiquement la
compilation — retourne dans **Actions** pour récupérer le nouvel APK.

## Relancer une compilation sans rien modifier

Onglet **Actions** → **Build Android APK** (menu de gauche) → bouton **Run workflow** →
**Run workflow**. Utile si tu veux juste reconstruire sans changer de code.

## Notes

- **Icône de l'app** : le fichier source haute résolution est dans `resources/icon.png`
  (et dupliqué dans `assets/icon.png` par sécurité — selon la version de l'outil, l'un ou
  l'autre est utilisé). L'étape "Générer les icônes" du workflow s'en sert automatiquement
  pour produire toutes les tailles nécessaires à Android (lanceur, adaptive icon, etc.).
  Si cette étape échoue pour une raison quelconque, l'APK se compile quand même mais avec
  l'icône par défaut de Capacitor — dis-le-moi si c'est le cas, on ajustera.
- `appId` (`ht.canaan.eve`) est l'identifiant unique de l'app. Il ne pourra plus changer si
  tu publies un jour sur le Play Store.
- L'APK produit ici est un APK de **debug** (non signé pour la distribution publique) —
  parfait pour ton usage personnel. Pour publier sur le Play Store un jour, il faudra un
  APK signé ; ça se prépare aussi via GitHub Actions, dis-le-moi le moment venu.
- Le service worker (`sw.js`) permet à l'app de fonctionner hors connexion une fois ouverte
  une première fois.
